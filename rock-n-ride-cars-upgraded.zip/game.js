(() => {
"use strict";
const canvas=document.getElementById("game"),ctx=canvas.getContext("2d");
let W=innerWidth,H=innerHeight,dpr=Math.min(devicePixelRatio||1,2);
function resize(){W=innerWidth;H=innerHeight;canvas.width=W*dpr;canvas.height=H*dpr;ctx.setTransform(dpr,0,0,dpr,0,0)}
addEventListener("resize",resize);resize();

const clamp=(v,a,b)=>Math.max(a,Math.min(b,v)),rand=(a,b)=>a+Math.random()*(b-a);
const keys={left:false,right:false,gas:false,brake:false,nitro:false};
addEventListener("keydown",e=>{const k=e.key.toLowerCase(); if(["arrowleft","a"].includes(k))keys.left=true;if(["arrowright","d"].includes(k))keys.right=true;if(["arrowup","w"].includes(k))keys.gas=true;if(["arrowdown","s"].includes(k))keys.brake=true;if(k===" ")keys.nitro=true;if(k==="p")togglePause()});
addEventListener("keyup",e=>{const k=e.key.toLowerCase();if(["arrowleft","a"].includes(k))keys.left=false;if(["arrowright","d"].includes(k))keys.right=false;if(["arrowup","w"].includes(k))keys.gas=false;if(["arrowdown","s"].includes(k))keys.brake=false;if(k===" ")keys.nitro=false});
document.querySelectorAll("#touch button").forEach(b=>{const k=b.dataset.key;b.addEventListener("pointerdown",e=>{e.preventDefault();keys[k]=true});["pointerup","pointercancel","pointerleave"].forEach(t=>b.addEventListener(t,e=>{e.preventDefault();keys[k]=false}))});

let running=false,paused=false,time=0,night=0.15,score=0;
const limitEl=document.getElementById("limit"),speedEl=document.getElementById("speed"),wantedEl=document.getElementById("wanted"),mission=document.getElementById("mission");
const cars=[];
const carColors=["#e9edf2","#f05b55","#4ca6ff","#ffd35c","#8ee28e","#c08cff","#ff8b3d","#67e8e8","#ff78b9","#aeb8c4","#e7e24e","#7b8cff","#f3f3f3","#ff5d7a","#67c26f"];
for(let i=0;i<15;i++)cars.push({x:rand(-.42,.42),y:rand(-2600,900),lane:rand(-.36,.36),speed:rand(.8,1.5),c:carColors[i],name:["Nova","Raptor","Volt","Apex","Drift","Blaze","Comet","Viper","Pulse","Storm","Turbo","Phantom","Rocket","Neon","Titan"][i]});
let player={x:0,y:0,v:0,angle:0,c:"#f2f4f5",name:"Jesko",nitro:100};
const ramps=Array.from({length:15},(_,i)=>({x:rand(-.38,.38),y:-450-i*520,h:0}));
const signs=Array.from({length:11},(_,i)=>({x:(i%2?-0.47:0.47),y:-250-i*700,limit:[40,50,60,70,80][i%5]}));
const police=[];
function spawnPolice(){if(police.length<5)police.push({x:rand(-.48,.48),y:-1200,spd:1.6+police.length*.12,phase:rand(0,9)})}

function roadAt(y){return 0} // open winding road is projected below
function roadCenter(y){return Math.sin(y*.0012)*.22+Math.sin(y*.0029)*.08}
function project(x,y,scale=1){const horizon=H*.38;const sy=horizon+(y+650)*.42*scale;const center=W/2+roadCenter(y)*W*.7;const roadW=W*(.13+Math.min(1,Math.max(0,(sy-horizon)/(H-horizon)))*.38);return {x:center+x*roadW*2,y:sy,w:roadW}}
function carScreen(x,y){return project(x,y,1)}

function drawWorld(){
  const grad=ctx.createLinearGradient(0,0,0,H);
  const n=clamp(night,0,1);
  grad.addColorStop(0,`rgb(${10-4*n},${31-17*n},${43-15*n})`);
  grad.addColorStop(1,`rgb(${22-12*n},${64-34*n},${47-23*n})`);
  ctx.fillStyle=grad;ctx.fillRect(0,0,W,H);
  // stars at night
  if(n>.45){ctx.fillStyle="#ffffffaa";for(let i=0;i<80;i++){let x=(i*83)%W,y=(i*47)%(H*.45);ctx.fillRect(x,y,1,1)}}
  // landscape
  ctx.fillStyle=n>.5?"#091311":"#173824";ctx.beginPath();ctx.moveTo(0,H*.38);for(let x=0;x<=W;x+=40)ctx.lineTo(x,H*.34+Math.sin(x*.01)*18);ctx.lineTo(W,H);ctx.lineTo(0,H);ctx.fill();
  // road as connected perspective slices, deliberately not a grid
  ctx.fillStyle=n>.5?"#20282b":"#394145";
  ctx.beginPath();ctx.moveTo(W*.5,H*.38);
  for(let y=H*.38;y<=H+30;y+=12){let yy=(y-H*.38)/(H*.62);let c=W/2+Math.sin((time*1.1+y)*.002)*W*.12;let rw=W*(.08+.43*yy);ctx.lineTo(c-rw,y)}
  for(let y=H+30;y>=H*.38;y-=12){let yy=(y-H*.38)/(H*.62);let c=W/2+Math.sin((time*1.1+y)*.002)*W*.12;let rw=W*(.08+.43*yy);ctx.lineTo(c+rw,y)}
  ctx.closePath();ctx.fill();
  // edge lines
  ctx.strokeStyle="#ffffff55";ctx.lineWidth=3;ctx.beginPath();
  for(const side of [-1,1]){ctx.moveTo(W/2,H*.38);for(let y=H*.38;y<=H;y+=14){let yy=(y-H*.38)/(H*.62),c=W/2+Math.sin((time*1.1+y)*.002)*W*.12,rw=W*(.08+.43*yy);ctx.lineTo(c+side*rw,y)}}
  ctx.stroke();
  // center broken markings
  ctx.strokeStyle="#f7df83cc";ctx.lineWidth=4;ctx.setLineDash([28,28]);ctx.beginPath();ctx.moveTo(W/2,H*.39);ctx.lineTo(W/2,H);ctx.stroke();ctx.setLineDash([]);
}

function drawRamp(r){
  const p=project(r.x,r.y);
  if(p.y< H*.38-30 || p.y>H+100)return;
  const w=p.w*.55,h=clamp(p.w*.28,16,80);
  ctx.save();ctx.translate(p.x,p.y);
  ctx.fillStyle="#b8c0c4";ctx.beginPath();ctx.moveTo(-w,8);ctx.lineTo(w,8);ctx.lineTo(w*.7,-h);ctx.lineTo(-w*.7,-h);ctx.closePath();ctx.fill();
  ctx.fillStyle="#202a30";ctx.fillRect(-w*.65,-h*.75,w*1.3,6);
  ctx.restore();
}

function drawSign(s){
 const p=project(s.x,s.y);if(p.y<40||p.y>H+50)return;
 ctx.save();ctx.translate(p.x,p.y);ctx.strokeStyle="#777";ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(0,70);ctx.stroke();
 ctx.fillStyle="#fff";ctx.beginPath();ctx.arc(0,-10,23,0,Math.PI*2);ctx.fill();ctx.strokeStyle="#d22";ctx.stroke();
 ctx.fillStyle="#111";ctx.font="bold 12px Arial";ctx.textAlign="center";ctx.fillText(s.limit,0,-6);ctx.restore();
}

function drawCar(x,y,c,scale=.6,police=false){
 const p=project(x,y);if(p.y<-80||p.y>H+120)return;
 const w=clamp(p.w*.25*scale,9,55),h=w*1.65;
 ctx.save();ctx.translate(p.x,p.y);
 ctx.fillStyle="#0008";ctx.beginPath();ctx.ellipse(0,h*.42,w*1.25,h*.25,0,0,Math.PI*2);ctx.fill();
 ctx.fillStyle=c;ctx.beginPath();ctx.roundRect(-w,-h/2,w*2,h,Math.min(w*.35,10));ctx.fill();
 ctx.fillStyle="#15212a";ctx.beginPath();ctx.roundRect(-w*.62,-h*.25,w*1.24,h*.38,5);ctx.fill();
 ctx.fillStyle="#fff";ctx.fillRect(-w*.65,-h*.43,w*.28,5);ctx.fillRect(w*.37,-h*.43,w*.28,5);
 if(police){ctx.fillStyle="#e33";ctx.fillRect(-w*.5,-h*.48,w*.45,5);ctx.fillStyle="#48a8ff";ctx.fillRect(w*.05,-h*.48,w*.45,5)}
 ctx.restore();
}

function update(dt){
 if(!running||paused)return;
 time+=dt;
 night=(Math.sin(time*.035-Math.PI/2)+1)/2;
 player.v += (keys.gas?1.1:0)*dt;
 player.v -= (keys.brake?2.0:0)*dt;
 player.v -= .42*dt;
 if(keys.nitro&&player.nitro>0){player.v+=2.2*dt;player.nitro-=18*dt}else player.nitro=Math.min(100,player.nitro+5*dt);
 player.v=clamp(player.v,0,2.6);
 player.x += ((keys.right?1:0)-(keys.left?1:0))*dt*(.75+player.v*.28);
 player.x=clamp(player.x,-.72,.72);
 // Move world toward player.
 for(const c of cars){c.y += (player.v-c.speed)*dt*700;if(c.y>950)c.y=-3000-rand(0,2500);if(c.y<-4000)c.y=800}
 for(const r of ramps){r.y+=(player.v)*dt*700;if(r.y>1000)r.y=-8500-rand(0,2000)}
 for(const s of signs){s.y+=(player.v)*dt*700;if(s.y>1000)s.y=-7000-rand(0,1500)}
 // Police spawn when speeding near a sign.
 let nearbyLimit=60;
 for(const s of signs)if(Math.abs(s.y)<300)nearbyLimit=s.limit;
 const kmh=Math.round(player.v*55);
 if(kmh>nearbyLimit+12){score+=dt; if(score>1.5){spawnPolice();score=0;mission.textContent="POLICE ALERT • Slow down or escape!";mission.classList.add("flash");setTimeout(()=>mission.classList.remove("flash"),700)}} else score=Math.max(0,score-dt);
 for(const p of police){p.y+=(player.v-p.spd)*dt*700;p.x+=(Math.sin(time+p.phase)*.08)*dt;if(p.y>900){p.y=-2500;}}
 // collision -> switch car
 for(const c of cars){if(Math.abs(c.y)<120&&Math.abs(c.x-player.x)<.13){player.c=c.c;player.name=c.name;mission.textContent="SWITCHED TO "+c.name.toUpperCase()+" • Keep driving!";c.y=-3000-rand(0,1800)}}
 // police catch
 for(const p of police){if(Math.abs(p.y)<90&&Math.abs(p.x-player.x)<.12){player.v*=.45;mission.textContent="CAUGHT! Lose the police and try again.";wantedEl.textContent="⚠";}}
 limitEl.textContent=nearbyLimit;
 speedEl.textContent=kmh;
 wantedEl.textContent=Math.min(5,police.length);
 document.body.classList.toggle("hot",police.length>0);
}

function draw(){
 drawWorld();
 // draw far objects first
 ramps.slice().sort((a,b)=>a.y-b.y).forEach(r=>drawRamp(r));
 signs.slice().sort((a,b)=>a.y-b.y).forEach(drawSign);
 cars.slice().sort((a,b)=>a.y-b.y).forEach(c=>drawCar(c.x,c.y,c.c,.75,false));
 police.slice().sort((a,b)=>a.y-b.y).forEach(p=>drawCar(p.x,p.y,"#fff",.85,true));
 drawCar(player.x,0,player.c,1.05,false);
 // nitro meter
 ctx.fillStyle="#0008";ctx.fillRect(18,H-90,150,8);ctx.fillStyle="#fff";ctx.fillRect(18,H-90,150*(player.nitro/100),8);
 ctx.fillStyle="#fff";ctx.font="10px Arial";ctx.fillText("NITRO",18,H-97);
 if(paused){ctx.fillStyle="#0009";ctx.fillRect(0,0,W,H);ctx.fillStyle="#fff";ctx.font="900 42px Arial";ctx.textAlign="center";ctx.fillText("PAUSED",W/2,H/2);ctx.textAlign="left")}
}
let last=performance.now();function loop(now){const dt=Math.min(.04,(now-last)/1000);last=now;update(dt);draw();requestAnimationFrame(loop)}requestAnimationFrame(loop);

function togglePause(){if(!running)return;paused=!paused;document.getElementById("pause").textContent=paused?"▶":"Ⅱ"}
document.getElementById("pause").onclick=togglePause;
document.getElementById("daynight").onclick=()=>{night=night<.5?1:0};
document.getElementById("music").onclick=()=>document.getElementById("audioPanel").classList.toggle("hidden");

document.getElementById("startBtn").onclick=()=>{running=true;document.getElementById("start").classList.add("hidden");mission.textContent="GO! • 15 cars • 15 ramps • Watch the speed signs"};
const af=document.getElementById("audioFiles"),playerAudio=document.getElementById("player"),track=document.getElementById("trackName");
af.onchange=()=>{if(af.files[0]){const url=URL.createObjectURL(af.files[0]);playerAudio.src=url;track.textContent=af.files[0].name;playerAudio.play().catch(()=>{})}};
document.getElementById("spotify").onclick=()=>window.open("https://open.spotify.com/","_blank","noopener");

draw();
})();