# Rock'n Ride Cars — GitHub Pages build

This package preserves the original uploaded project files and adds a clean static
entry point for GitHub Pages:

- `index.html` — static game entry point
- `style.css` — game UI and responsive styling
- `game.js` — driving, 15 cars, 15 ramps, speed-limit police, day/night, touch/keyboard controls
- `assets/` and other original files — preserved from the uploaded project

Open the repository root with GitHub Pages. `index.html` must remain at the repository root.

Music:
- Use the Music button to load local audio files.
- The Spotify button opens Spotify. A static GitHub Pages game cannot freely play a
  user's Spotify account tracks without Spotify authentication/API integration.
